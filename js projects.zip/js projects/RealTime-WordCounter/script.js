document.addEventListener("DOMContentLoaded", function() {
    const textInput = document.getElementById("textInput");
    const wordCountDisplay = document.getElementById("wordCount");

    textInput.addEventListener("input", function() {
        const text = textInput.value.trim();
        const words = text === "" ? 0 : text.split(/\s+/).filter(word => word.length > 0).length;
        wordCountDisplay.textContent = words;
    });
});
